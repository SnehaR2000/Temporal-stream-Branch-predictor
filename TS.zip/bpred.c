/* bpred.c - branch predictor routines */

/* SimpleScalar(TM) Tool Suite
 * Copyright (C) 1994-2003 by Todd M. Austin, Ph.D. and SimpleScalar, LLC.
 * All Rights Reserved.
 *
 * THIS IS A LEGAL DOCUMENT, BY USING SIMPLESCALAR,
 * YOU ARE AGREEING TO THESE TERMS AND CONDITIONS.
 *
 * No portion of this work may be used by any commercial entity, or for any
 * commercial purpose, without the prior, written permission of SimpleScalar,
 * LLC (info@simplescalar.com). Nonprofit and noncommercial use is permitted
 * as described below.
 *
 * 1. SimpleScalar is provided AS IS, with no warranty of any kind, express
 * or implied. The user of the program accepts full responsibility for the
 * application of the program and the use of any results.
 *
 * 2. Nonprofit and noncommercial use is encouraged. SimpleScalar may be
 * downloaded, compiled, executed, copied, and modified solely for nonprofit,
 * educational, noncommercial research, and noncommercial scholarship
 * purposes provided that this notice in its entirety accompanies all copies.
 * Copies of the modified software can be delivered to persons who use it
 * solely for nonprofit, educational, noncommercial research, and
 * noncommercial scholarship purposes provided that this notice in its
 * entirety accompanies all copies.
 *
 * 3. ALL COMMERCIAL USE, AND ALL USE BY FOR PROFIT ENTITIES, IS EXPRESSLY
 * PROHIBITED WITHOUT A LICENSE FROM SIMPLESCALAR, LLC (info@simplescalar.com).
 *
 * 4. No nonprofit user may place any restrictions on the use of this software,
 * including as modified by the user, by any other authorized user.
 *
 * 5. Noncommercial and nonprofit users may distribute copies of SimpleScalar
 * in compiled or executable form as set forth in Section 2, provided that
 * either: (A) it is accompanied by the corresponding machine-readable source
 * code, or (B) it is accompanied by a written offer, with no time limit, to
 * give anyone a machine-readable copy of the corresponding source code in
 * return for reimbursement of the cost of distribution. This written offer
 * must permit verbatim duplication by anyone, or (C) it is distributed by
 * someone who received only the executable form, and is accompanied by a
 * copy of the written offer of source code.
 *
 * 6. SimpleScalar was developed by Todd M. Austin, Ph.D. The tool suite is
 * currently maintained by SimpleScalar LLC (info@simplescalar.com). US Mail:
 * 2395 Timbercrest Court, Ann Arbor, MI 48105.
 *
 * Copyright (C) 1994-2003 by Todd M. Austin, Ph.D. and SimpleScalar, LLC.
 */

 // modified here
 /*
 The original file was modified for the ECE587 final project where a temporal
 stream branch predictor is implemented
 */


#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <assert.h>
#include <stdbool.h>  // modified here
#include <inttypes.h> // modified here

#include "host.h"
#include "misc.h"
#include "machine.h"
#include "bpred.h"


// modified here
// declare the variables, buffers and tables to be used with the temporal stream version

int144_t history_state_144 = {0}; // store shifted history of program to use to hash the key, will have to trim from 144 to 140 bits to match paper


/////////////////// Circular Buffer //////////////////////////////
CircBuffer_t* create_circ_buffer(int32_t max_qty) {  // create the circular buffer variable instance
    CircBuffer_t* cb = (CircBuffer_t*)calloc(1,sizeof(CircBuffer_t));
    if(!(cb)) { // verify if dynamic memory is available
        fatal("out of virtual memory at circular buffer");
    }
    cb->buffer = (bool*)calloc(max_qty, sizeof(bool));
    cb->head = 0;
    cb->tail = 0;
    cb->max_qty = max_qty;
    return cb;
}

// add an item to the circular buffer
void circ_buffer_push(CircBuffer_t *cb, bool bit_in) {
    int32_t next;
    next = cb->tail + 1; // used to verify if buffer has space
    if(next >= cb->max_qty) // if reached the end of circular buffer, wrap around to location zero
        next = 0;
    
    if(next == cb->head)  // if tail + 1 = head, then buffer is full
        fatal("Circular buffer was not big enough... next= %d and cb->head= %d", next, cb->head);

    cb->buffer[cb->tail] = bit_in;  // store bit to the tail of the circular buffer
    cb->tail = next;  // update the tail index to next empty spot
}

/* the article used large enough buffer to not run out of space for the simulations, will try to do the same for our simulations
// clear items from circular buffer once not needed anymore by the head table oldest index that got overwritten
void circ_buffer_partial_release(CircBuffer_t *cb, place here head table line that updated...) {
    compare the old index being overwriten to all other indexes in head table, if it is the oldest, then release until the second oldest
    else keep as is
    this help to keep only the history for items still in the head table, discarding the rest of older values
}
*/


//////////////////// Circular Head Table //////////////////////////////////
CircTable_t* create_circ_table(int32_t max_qty) {  // create the circular table variable instance
    CircTable_t* ct = (CircTable_t*)calloc(1,sizeof(CircTable_t));
    if(!(ct)) { // verify if dynamic memory is available
        fatal("out of virtual memory at circular table");
    }
    ct->buffer = (struct ht_line*)calloc(max_qty, sizeof(struct ht_line));
    ct->head = 0;
    ct->tail = 0;
    ct->max_qty = max_qty;
    return ct;
}

struct key_var hash_key(int144_t history_state_144, md_addr_t PC) {  // create the hash key
    struct key_var key_data;
    key_data.data_low = ((history_state_144.low_64 << 32) | PC);
    key_data.data_mid = ((history_state_144.mid_64 << 32) | (history_state_144.low_64 >> 32));
    key_data.data_up = (history_state_144.upper_16);
    key_data.data_up = ((key_data.data_up << 32) | (history_state_144.mid_64 >> 32));
    // now we have the hash key with 3*64=192, only pass 140+32 = 172 bits
    key_data.data_up = key_data.data_up & 0x00000FFFFFFFFFFF; // mask the upper 20 bits that are not used
    
    /*debug("Value history_state_144.low_64 = %lx \n", history_state_144.low_64);
    debug("Value history_state_144.mid_64 = %lx \n", history_state_144.mid_64);
    debug("Value history_state_144.upper_16 = %lx \n", history_state_144.upper_16);
    debug("Value PC = %lx \n", PC);
    
    debug("Value key_data.data_low = %lx \n", key_data.data_low);
    debug("Value key_data.data_mid = %lx \n", key_data.data_mid);
    debug("Value key_data.data_up = %lx \n", key_data.data_up);
    */
    return key_data;
}

// find if key already in table, return value if found, and add an item to the circular table or replace with new value
struct key_match_head circ_table_push(CircTable_t *ct, CircBuffer_t *cb, struct key_var key_in) {
    int32_t next;
    int j; // to be used by the for loops
    struct key_match_head out_values; // create instance of the values to be returned by function

    out_values.match_bit = false; // initialize to zero at each new entrance

    next = ct->tail + 1; // used to verify if buffer has space
    if(next >= ct->max_qty) // if reached the end of circular buffer, wrap around to location zero
        next = 0;

    if (next == ct->head)  // if tail + 1 = head, then buffer is full
        fatal("Circular table was not big enough...");

    if((ct->tail) >= (ct->head)) {
        for(j=0; j < ((ct->tail)-(ct->head)); j++) {  // iterate through the upper side of the table
            if(ct->buffer[(ct->head)+j].key_line.data_low == key_in.data_low) {
                if(ct->buffer[(ct->head)+j].key_line.data_mid == key_in.data_mid) {
                  if(ct->buffer[(ct->head)+j].key_line.data_up == key_in.data_up) {
                    out_values.match_head = ct->buffer[(ct->head)+j].head_start; // get a copy before overriding it
                    ct->buffer[(ct->head)+j].head_start = cb->tail; // update table with new tail to be used as head
                    out_values.indice_new = cb->tail;
                    out_values.match_bit = true; // a match was found
                    break;
                  }
                }
            }
        }
    }
    else { // it wrapped around
        for(j=0; j < ((ct->max_qty)-(ct->head)); j++) {  // iterate through the upper side of the table
            if(ct->buffer[(ct->head)+j].key_line.data_low == key_in.data_low) {
                if(ct->buffer[(ct->head)+j].key_line.data_mid == key_in.data_mid) {
                  if(ct->buffer[(ct->head)+j].key_line.data_up == key_in.data_up) {
                    out_values.match_head = ct->buffer[(ct->head)+j].head_start; // get a copy before overriding it
                    ct->buffer[(ct->head)+j].head_start = cb->tail; // update table with new tail to be used as head
                    out_values.indice_new = cb->tail;
                    out_values.match_bit = true; // a match was found
                    break;
                  }
                }
            }
        }
        for(j=0; j < ((ct->tail)); j++) {  // iterate through the lower side of the table
            if(ct->buffer[j].key_line.data_low == key_in.data_low) {
                if(ct->buffer[j].key_line.data_mid == key_in.data_mid) {
                  if(ct->buffer[j].key_line.data_up == key_in.data_up) {
                    out_values.match_head = ct->buffer[j].head_start; // get a copy before overriding it
                    ct->buffer[j].head_start = cb->tail; // update table with new tail to be used as head
                    out_values.indice_new = cb->tail;
                    out_values.match_bit = true; // a match was found
                    break;
                  }
                }  
            }
        }
    }

    if(out_values.match_bit == false) {
        ct->buffer[next].head_start = cb->tail; // add to table a new line with new tail to be used as head during a future match
        ct->buffer[next].key_line.data_low = key_in.data_low; // also include to table the key to the new line to allow future matches
        ct->buffer[next].key_line.data_mid = key_in.data_mid;
        ct->buffer[next].key_line.data_up = key_in.data_up;
        ct->tail = next; // update the tail index to account for the new line added
    }

    return out_values;
}

/* the article used large enough table to not run out of space for the simulations, will try to do the same for our simulations
// clear items from circular table once not needed anymore (maybe used least recently used line to decide what to kick out???)
void circ_table_partial_release(CircTable_t *ct, place here condition...) {
    we have a few options, maybe use a smaller size table and frequently replace the least recently used line, this helps with needing a smaller buffer,
    or use a larger size table with least recently used replacement and give the buffer the option to remove the oldest line from table
    when the buffer is about to run out of space.
}
*/



/* turn this on to enable the SimpleScalar 2.0 RAS bug */
/* #define RAS_BUG_COMPATIBLE */

/* create a branch predictor */
struct bpred_t *			/* branch predictory instance */
bpred_create(enum bpred_class class,	/* type of predictor to create */
	     unsigned int bimod_size,	/* bimod table size */
	     unsigned int l1size,	/* 2lev l1 table size */
	     unsigned int l2size,	/* 2lev l2 table size */
	     unsigned int meta_size,	/* meta table size */
	     unsigned int shift_width,	/* history register width */
	     unsigned int xor,  	/* history xor address flag */
	     unsigned int btb_sets,	/* number of sets in BTB */
	     unsigned int btb_assoc,	/* BTB associativity */
	     unsigned int retstack_size) /* num entries in ret-addr stack */
{
  struct bpred_t *pred;

  if (!(pred = calloc(1, sizeof(struct bpred_t))))
    fatal("out of virtual memory");

  pred->class = class;

  switch (class) {
  case BPredComb:
    /* bimodal component */
    pred->dirpred.bimod =
      bpred_dir_create(BPred2bit, bimod_size, 0, 0, 0);

    /* 2-level component */
    pred->dirpred.twolev =
      bpred_dir_create(BPred2Level, l1size, l2size, shift_width, xor);

    /* metapredictor component */
    pred->dirpred.meta =
      bpred_dir_create(BPred2bit, meta_size, 0, 0, 0);

    break;

  case BPred2Level:
    pred->dirpred.twolev =
      bpred_dir_create(class, l1size, l2size, shift_width, xor);

    break;

  case BPred2bit:
    pred->dirpred.bimod =
      bpred_dir_create(class, bimod_size, 0, 0, 0);

  case BPredTaken:
  case BPredNotTaken:
    /* no other state */
    break;

  default:
    panic("bogus predictor class");
  }

  /* allocate ret-addr stack */
  switch (class) {
  case BPredComb:
  case BPred2Level:
  case BPred2bit:
    {
      int i;

      /* allocate BTB */
      if (!btb_sets || (btb_sets & (btb_sets-1)) != 0)
	fatal("number of BTB sets must be non-zero and a power of two");
      if (!btb_assoc || (btb_assoc & (btb_assoc-1)) != 0)
	fatal("BTB associativity must be non-zero and a power of two");

      if (!(pred->btb.btb_data = calloc(btb_sets * btb_assoc,
					sizeof(struct bpred_btb_ent_t))))
	fatal("cannot allocate BTB");

      pred->btb.sets = btb_sets;
      pred->btb.assoc = btb_assoc;

      if (pred->btb.assoc > 1)
	for (i=0; i < (pred->btb.assoc*pred->btb.sets); i++)
	  {
	    if (i % pred->btb.assoc != pred->btb.assoc - 1)
	      pred->btb.btb_data[i].next = &pred->btb.btb_data[i+1];
	    else
	      pred->btb.btb_data[i].next = NULL;

	    if (i % pred->btb.assoc != pred->btb.assoc - 1)
	      pred->btb.btb_data[i+1].prev = &pred->btb.btb_data[i];
	  }

      /* allocate retstack */
      if ((retstack_size & (retstack_size-1)) != 0)
	fatal("Return-address-stack size must be zero or a power of two");

      pred->retstack.size = retstack_size;
      if (retstack_size)
	if (!(pred->retstack.stack = calloc(retstack_size,
					    sizeof(struct bpred_btb_ent_t))))
	  fatal("cannot allocate return-address-stack");
      pred->retstack.tos = retstack_size - 1;

      break;
    }

  case BPredTaken:
  case BPredNotTaken:
    /* no other state */
    break;

  default:
    panic("bogus predictor class");
  }

  return pred;
}

/* create a branch direction predictor */
struct bpred_dir_t *		/* branch direction predictor instance */
bpred_dir_create (
  enum bpred_class class,	/* type of predictor to create */
  unsigned int l1size,	 	/* level-1 table size */
  unsigned int l2size,	 	/* level-2 table size (if relevant) */
  unsigned int shift_width,	/* history register width */
  unsigned int xor)	    	/* history xor address flag */
{
  struct bpred_dir_t *pred_dir;
  unsigned int cnt;
  int flipflop;

  if (!(pred_dir = calloc(1, sizeof(struct bpred_dir_t))))
    fatal("out of virtual memory");

  pred_dir->class = class;

  cnt = -1;
  switch (class) {
  case BPred2Level:
    {
      if (!l1size || (l1size & (l1size-1)) != 0)
	fatal("level-1 size, `%d', must be non-zero and a power of two",
	      l1size);
      pred_dir->config.two.l1size = l1size;

      if (!l2size || (l2size & (l2size-1)) != 0)
	fatal("level-2 size, `%d', must be non-zero and a power of two",
	      l2size);
      pred_dir->config.two.l2size = l2size;

      if (!shift_width || shift_width > 30)
	fatal("shift register width, `%d', must be non-zero and positive",
	      shift_width);
      pred_dir->config.two.shift_width = shift_width;

      pred_dir->config.two.xor = xor;
      pred_dir->config.two.shiftregs = calloc(l1size, sizeof(int));
      if (!pred_dir->config.two.shiftregs)
	fatal("cannot allocate shift register table");

      pred_dir->config.two.l2table = calloc(l2size, sizeof(unsigned char));
      if (!pred_dir->config.two.l2table)
	fatal("cannot allocate second level table");

      /* initialize counters to weakly this-or-that */
      flipflop = 1;
      for (cnt = 0; cnt < l2size; cnt++)
	{
	  pred_dir->config.two.l2table[cnt] = flipflop;
	  flipflop = 3 - flipflop;
	}

      break;
    }

  case BPred2bit:
    if (!l1size || (l1size & (l1size-1)) != 0)
      fatal("2bit table size, `%d', must be non-zero and a power of two",
	    l1size);
    pred_dir->config.bimod.size = l1size;
    if (!(pred_dir->config.bimod.table =
	  calloc(l1size, sizeof(unsigned char))))
      fatal("cannot allocate 2bit storage");
    /* initialize counters to weakly this-or-that */
    flipflop = 1;
    for (cnt = 0; cnt < l1size; cnt++)
      {
	pred_dir->config.bimod.table[cnt] = flipflop;
	flipflop = 3 - flipflop;
      }

    break;

  case BPredTaken:
  case BPredNotTaken:
    /* no other state */
    break;

  default:
    panic("bogus branch direction predictor class");
  }

  return pred_dir;
}

/* print branch direction predictor configuration */
void
bpred_dir_config(
  struct bpred_dir_t *pred_dir,	/* branch direction predictor instance */
  char name[],			/* predictor name */
  FILE *stream)			/* output stream */
{
  switch (pred_dir->class) {
  case BPred2Level:
    fprintf(stream,
      "pred_dir: %s: 2-lvl: %d l1-sz, %d bits/ent, %s xor, %d l2-sz, direct-mapped\n",
      name, pred_dir->config.two.l1size, pred_dir->config.two.shift_width,
      pred_dir->config.two.xor ? "" : "no", pred_dir->config.two.l2size);
    break;

  case BPred2bit:
    fprintf(stream, "pred_dir: %s: 2-bit: %d entries, direct-mapped\n",
      name, pred_dir->config.bimod.size);
    break;

  case BPredTaken:
    fprintf(stream, "pred_dir: %s: predict taken\n", name);
    break;

  case BPredNotTaken:
    fprintf(stream, "pred_dir: %s: predict not taken\n", name);
    break;

  default:
    panic("bogus branch direction predictor class");
  }
}

/* print branch predictor configuration */
void
bpred_config(struct bpred_t *pred,	/* branch predictor instance */
	     FILE *stream)		/* output stream */
{
  switch (pred->class) {
  case BPredComb:
    bpred_dir_config (pred->dirpred.bimod, "bimod", stream);
    bpred_dir_config (pred->dirpred.twolev, "2lev", stream);
    bpred_dir_config (pred->dirpred.meta, "meta", stream);
    fprintf(stream, "btb: %d sets x %d associativity",
	    pred->btb.sets, pred->btb.assoc);
    fprintf(stream, "ret_stack: %d entries", pred->retstack.size);
    break;

  case BPred2Level:
    bpred_dir_config (pred->dirpred.twolev, "2lev", stream);
    fprintf(stream, "btb: %d sets x %d associativity",
	    pred->btb.sets, pred->btb.assoc);
    fprintf(stream, "ret_stack: %d entries", pred->retstack.size);
    break;

  case BPred2bit:
    bpred_dir_config (pred->dirpred.bimod, "bimod", stream);
    fprintf(stream, "btb: %d sets x %d associativity",
	    pred->btb.sets, pred->btb.assoc);
    fprintf(stream, "ret_stack: %d entries", pred->retstack.size);
    break;

  case BPredTaken:
    bpred_dir_config (pred->dirpred.bimod, "taken", stream);
    break;
  case BPredNotTaken:
    bpred_dir_config (pred->dirpred.bimod, "nottaken", stream);
    break;

  default:
    panic("bogus branch predictor class");
  }
}

/* print predictor stats */
void
bpred_stats(struct bpred_t *pred,	/* branch predictor instance */
	    FILE *stream)		/* output stream */
{
  fprintf(stream, "pred: addr-prediction rate = %f\n",
	  (double)pred->addr_hits/(double)(pred->addr_hits+pred->misses));
  fprintf(stream, "pred: dir-prediction rate = %f\n",
	  (double)pred->dir_hits/(double)(pred->dir_hits+pred->misses));
}

/* register branch predictor stats */
void
bpred_reg_stats(struct bpred_t *pred,	/* branch predictor instance */
		struct stat_sdb_t *sdb)	/* stats database */
{
  char buf[512], buf1[512], *name;

  /* get a name for this predictor */
  switch (pred->class)
    {
    case BPredComb:
      name = "bpred_comb";
      break;
    case BPred2Level:
      name = "bpred_2lev";
      break;
    case BPred2bit:
      name = "bpred_bimod";
      break;
    case BPredTaken:
      name = "bpred_taken";
      break;
    case BPredNotTaken:
      name = "bpred_nottaken";
      break;
    default:
      panic("bogus branch predictor class");
    }

  sprintf(buf, "%s.lookups", name);
  stat_reg_counter(sdb, buf, "total number of bpred lookups",
		   &pred->lookups, 0, NULL);
  sprintf(buf, "%s.updates", name);
  sprintf(buf1, "%s.dir_hits + %s.misses", name, name);
  stat_reg_formula(sdb, buf, "total number of updates", buf1, "%12.0f");
  sprintf(buf, "%s.addr_hits", name);
  stat_reg_counter(sdb, buf, "total number of address-predicted hits",
		   &pred->addr_hits, 0, NULL);
  sprintf(buf, "%s.dir_hits", name);
  stat_reg_counter(sdb, buf,
		   "total number of direction-predicted hits "
		   "(includes addr-hits)",
		   &pred->dir_hits, 0, NULL);
  if (pred->class == BPredComb)
    {
      sprintf(buf, "%s.used_bimod", name);
      stat_reg_counter(sdb, buf,
		       "total number of bimodal predictions used",
		       &pred->used_bimod, 0, NULL);
      sprintf(buf, "%s.used_2lev", name);
      stat_reg_counter(sdb, buf,
		       "total number of 2-level predictions used",
		       &pred->used_2lev, 0, NULL);
    }
  sprintf(buf, "%s.misses", name);
  stat_reg_counter(sdb, buf, "total number of misses", &pred->misses, 0, NULL);
// modified here  
  sprintf(buf, "%s.num_entry_replay", name);
  stat_reg_counter(sdb, buf, "total number of entry to replay mode", &pred->num_entry_replay, 0, NULL);
  sprintf(buf, "%s.num_operations_replay", name);
  stat_reg_counter(sdb, buf, "total number of operations compared in replay mode", &pred->num_operations_replay, 0, NULL);
  sprintf(buf, "%s.num_inverted_replay", name);
  stat_reg_counter(sdb, buf, "total number of predictions inverted when in replay mode", &pred->num_inverted_replay, 0, NULL);
  sprintf(buf, "%s.num_operations_fallback", name);
  stat_reg_counter(sdb, buf, "total number of operations performed in fallback mode", &pred->num_operations_fallback, 0, NULL);
  sprintf(buf, "%s.num_debug_test", name);
  stat_reg_counter(sdb, buf, "num_debug_test", &pred->num_debug_test, 0, NULL);
  
  
  sprintf(buf, "%s.jr_hits", name);
  stat_reg_counter(sdb, buf,
		   "total number of address-predicted hits for JR's",
		   &pred->jr_hits, 0, NULL);
  sprintf(buf, "%s.jr_seen", name);
  stat_reg_counter(sdb, buf,
		   "total number of JR's seen",
		   &pred->jr_seen, 0, NULL);
  sprintf(buf, "%s.jr_non_ras_hits.PP", name);
  stat_reg_counter(sdb, buf,
		   "total number of address-predicted hits for non-RAS JR's",
		   &pred->jr_non_ras_hits, 0, NULL);
  sprintf(buf, "%s.jr_non_ras_seen.PP", name);
  stat_reg_counter(sdb, buf,
		   "total number of non-RAS JR's seen",
		   &pred->jr_non_ras_seen, 0, NULL);
  sprintf(buf, "%s.bpred_addr_rate", name);
  sprintf(buf1, "%s.addr_hits / %s.updates", name, name);
  stat_reg_formula(sdb, buf,
		   "branch address-prediction rate (i.e., addr-hits/updates)",
		   buf1, "%9.4f");
  sprintf(buf, "%s.bpred_dir_rate", name);
  sprintf(buf1, "%s.dir_hits / %s.updates", name, name);
  stat_reg_formula(sdb, buf,
		  "branch direction-prediction rate (i.e., all-hits/updates)",
		  buf1, "%9.4f");
  sprintf(buf, "%s.bpred_jr_rate", name);
  sprintf(buf1, "%s.jr_hits / %s.jr_seen", name, name);
  stat_reg_formula(sdb, buf,
		  "JR address-prediction rate (i.e., JR addr-hits/JRs seen)",
		  buf1, "%9.4f");
  sprintf(buf, "%s.bpred_jr_non_ras_rate.PP", name);
  sprintf(buf1, "%s.jr_non_ras_hits.PP / %s.jr_non_ras_seen.PP", name, name);
  stat_reg_formula(sdb, buf,
		   "non-RAS JR addr-pred rate (ie, non-RAS JR hits/JRs seen)",
		   buf1, "%9.4f");
  sprintf(buf, "%s.retstack_pushes", name);
  stat_reg_counter(sdb, buf,
		   "total number of address pushed onto ret-addr stack",
		   &pred->retstack_pushes, 0, NULL);
  sprintf(buf, "%s.retstack_pops", name);
  stat_reg_counter(sdb, buf,
		   "total number of address popped off of ret-addr stack",
		   &pred->retstack_pops, 0, NULL);
  sprintf(buf, "%s.used_ras.PP", name);
  stat_reg_counter(sdb, buf,
		   "total number of RAS predictions used",
		   &pred->used_ras, 0, NULL);
  sprintf(buf, "%s.ras_hits.PP", name);
  stat_reg_counter(sdb, buf,
		   "total number of RAS hits",
		   &pred->ras_hits, 0, NULL);
  sprintf(buf, "%s.ras_rate.PP", name);
  sprintf(buf1, "%s.ras_hits.PP / %s.used_ras.PP", name, name);
  stat_reg_formula(sdb, buf,
		   "RAS prediction rate (i.e., RAS hits/used RAS)",
		   buf1, "%9.4f");
}


void
bpred_after_priming(struct bpred_t *bpred)
{
  if (bpred == NULL)
    return;

  bpred->lookups = 0;
  bpred->addr_hits = 0;
  bpred->dir_hits = 0;
  bpred->used_ras = 0;
  bpred->used_bimod = 0;
  bpred->used_2lev = 0;
  bpred->jr_hits = 0;
  bpred->jr_seen = 0;
  bpred->misses = 0;
// modified here
  bpred->num_entry_replay = 0;
  bpred->num_operations_replay = 0;
  bpred->num_inverted_replay = 0;
  bpred->num_operations_fallback = 0;
  bpred->num_debug_test = 0;
  
  bpred->retstack_pops = 0;
  bpred->retstack_pushes = 0;
  bpred->ras_hits = 0;
}


#define BIMOD_HASH(PRED, ADDR)						\
  ((((ADDR) >> 19) ^ ((ADDR) >> MD_BR_SHIFT)) & ((PRED)->config.bimod.size-1))
    /* was: ((baddr >> 16) ^ baddr) & (pred->dirpred.bimod.size-1) */

/* predicts a branch direction */
char *						/* pointer to counter */
bpred_dir_lookup(struct bpred_dir_t *pred_dir,	/* branch dir predictor inst */
		 md_addr_t baddr)		/* branch address */
{
  unsigned char *p = NULL;

  /* Except for jumps, get a pointer to direction-prediction bits */
  switch (pred_dir->class) {
    case BPred2Level:
      {
	int l1index, l2index;

        /* traverse 2-level tables */
        l1index = (baddr >> MD_BR_SHIFT) & (pred_dir->config.two.l1size - 1);
        l2index = pred_dir->config.two.shiftregs[l1index];
        if (pred_dir->config.two.xor)
	  {
#if 1
	    /* this L2 index computation is more "compatible" to McFarling's
	       verison of it, i.e., if the PC xor address component is only
	       part of the index, take the lower order address bits for the
	       other part of the index, rather than the higher order ones */
	    l2index = (((l2index ^ (baddr >> MD_BR_SHIFT))
			& ((1 << pred_dir->config.two.shift_width) - 1))
		       | ((baddr >> MD_BR_SHIFT)
			  << pred_dir->config.two.shift_width));
#else
	    l2index = l2index ^ (baddr >> MD_BR_SHIFT);
#endif
	  }
	else
	  {
	    l2index =
	      l2index
		| ((baddr >> MD_BR_SHIFT) << pred_dir->config.two.shift_width);
	  }
        l2index = l2index & (pred_dir->config.two.l2size - 1);

        /* get a pointer to prediction state information */
        p = &pred_dir->config.two.l2table[l2index];
      }
      break;
    case BPred2bit:
      p = &pred_dir->config.bimod.table[BIMOD_HASH(pred_dir, baddr)];
      break;
    case BPredTaken:
    case BPredNotTaken:
      break;
    default:
      panic("bogus branch direction predictor class");
    }

  return (char *)p;
}

/* probe a predictor for a next fetch address, the predictor is probed
   with branch address BADDR, the branch target is BTARGET (used for
   static predictors), and OP is the instruction opcode (used to simulate
   predecode bits; a pointer to the predictor state entry (or null for jumps)
   is returned in *DIR_UPDATE_PTR (used for updating predictor state),
   and the non-speculative top-of-stack is returned in stack_recover_idx
   (used for recovering ret-addr stack after mis-predict).  */
// modified here
md_addr_t				/* predicted branch target addr */
bpred_lookup(struct bpred_t *pred,	/* branch predictor instance */
	     md_addr_t baddr,		/* branch address */
	     md_addr_t btarget,		/* branch target if taken */
	     enum md_opcode op,		/* opcode of instruction */
	     int is_call,		/* non-zero if inst is fn call */
	     int is_return,		/* non-zero if inst is fn return */
	     struct bpred_update_t *dir_update_ptr, /* pred state pointer */
	     int *stack_recover_idx,	/* Non-speculative top-of-stack;
					 * used on mispredict recovery */
       CircBuffer_t* cb, /* receive the pointer to the circular buffer */
       bool *point_to_fallback_mode_ctr, /* receive the pointer for the control bit used to identify if we are in fallback mode or not */
       uint32_t *count_increment,  // hold the index value when parsing the circular buffer
       uint32_t head_pointer) /* receive the head pointer for the key that matched so it can be used in the functions */
{
  struct bpred_btb_ent_t *pbtb = NULL;
  int index, i;
// modified here  
  uint32_t st_index=0; // used to hold value from pointer plus iteration to make an index when in replay mode

  if (!dir_update_ptr)
    panic("no bpred update record");

  /* if this is not a branch, return not-taken */
  if (!(MD_OP_FLAGS(op) & F_CTRL))
    return 0;

  pred->lookups++;

  dir_update_ptr->dir.ras = FALSE;
  dir_update_ptr->pdir1 = NULL;
  dir_update_ptr->pdir2 = NULL;
  dir_update_ptr->pmeta = NULL;
  /* Except for jumps, get a pointer to direction-prediction bits */
  switch (pred->class) {
    case BPredComb:
      if ((MD_OP_FLAGS(op) & (F_CTRL|F_UNCOND)) != (F_CTRL|F_UNCOND))
	{
	  char *bimod, *twolev, *meta;
	  bimod = bpred_dir_lookup (pred->dirpred.bimod, baddr);
	  twolev = bpred_dir_lookup (pred->dirpred.twolev, baddr);
	  meta = bpred_dir_lookup (pred->dirpred.meta, baddr);
	  dir_update_ptr->pmeta = meta;
	  dir_update_ptr->dir.meta  = (*meta >= 2);
	  dir_update_ptr->dir.bimod = (*bimod >= 2);
	  dir_update_ptr->dir.twolev  = (*twolev >= 2);
	  if (*meta >= 2)
	    {
	      dir_update_ptr->pdir1 = twolev;
	      dir_update_ptr->pdir2 = bimod;
	    }
	  else
	    {
	      dir_update_ptr->pdir1 = bimod;
	      dir_update_ptr->pdir2 = twolev;
	    }
	}
      break;
    case BPred2Level:
      if ((MD_OP_FLAGS(op) & (F_CTRL|F_UNCOND)) != (F_CTRL|F_UNCOND))
	{
	  dir_update_ptr->pdir1 =
	    bpred_dir_lookup (pred->dirpred.twolev, baddr);
	}
      break;
    case BPred2bit:
      if ((MD_OP_FLAGS(op) & (F_CTRL|F_UNCOND)) != (F_CTRL|F_UNCOND))
	{
	  dir_update_ptr->pdir1 =
	    bpred_dir_lookup (pred->dirpred.bimod, baddr);
	}
      break;
    case BPredTaken:
      return btarget;
    case BPredNotTaken:
      if ((MD_OP_FLAGS(op) & (F_CTRL|F_UNCOND)) != (F_CTRL|F_UNCOND))
	{
	  return baddr + sizeof(md_inst_t);
	}
      else
	{
	  return btarget;
	}
    default:
      panic("bogus predictor class");
  }

  /*
   * We have a stateful predictor, and have gotten a pointer into the
   * direction predictor (except for jumps, for which the ptr is null)
   */

  /* record pre-pop TOS; if this branch is executed speculatively
   * and is squashed, we'll restore the TOS and hope the data
   * wasn't corrupted in the meantime. */
  if (pred->retstack.size)
    *stack_recover_idx = pred->retstack.tos;
  else
    *stack_recover_idx = 0;

  /* if this is a return, pop return-address stack */
  if (is_return && pred->retstack.size)
    {
      md_addr_t target = pred->retstack.stack[pred->retstack.tos].target;
      pred->retstack.tos = (pred->retstack.tos + pred->retstack.size - 1)
	                   % pred->retstack.size;
      pred->retstack_pops++;
      dir_update_ptr->dir.ras = TRUE; /* using RAS here */
      return target;
    }

#ifndef RAS_BUG_COMPATIBLE
  /* if function call, push return-address onto return-address stack */
  if (is_call && pred->retstack.size)
    {
      pred->retstack.tos = (pred->retstack.tos + 1)% pred->retstack.size;
      pred->retstack.stack[pred->retstack.tos].target =
	baddr + sizeof(md_inst_t);
      pred->retstack_pushes++;
    }
#endif /* !RAS_BUG_COMPATIBLE */

  /* not a return. Get a pointer into the BTB */
  index = (baddr >> MD_BR_SHIFT) & (pred->btb.sets - 1);

  if (pred->btb.assoc > 1)
    {
      index *= pred->btb.assoc;

      /* Now we know the set; look for a PC match */
      for (i = index; i < (index+pred->btb.assoc) ; i++)
	if (pred->btb.btb_data[i].addr == baddr)
	  {
	    /* match */
	    pbtb = &pred->btb.btb_data[i];
	    break;
	  }
    }
  else
    {
      pbtb = &pred->btb.btb_data[index];
      if (pbtb->addr != baddr)
	pbtb = NULL;
    }

  /*
   * We now also have a pointer into the BTB for a hit, or NULL otherwise
   */

  /* if this is a jump, ignore predicted direction; we know it's taken. */
  if ((MD_OP_FLAGS(op) & (F_CTRL|F_UNCOND)) == (F_CTRL|F_UNCOND))
    {
      return (pbtb ? pbtb->target : 1);
    }

// modified here
//pred->num_debug_test++;

  if(!!(*point_to_fallback_mode_ctr)) {  // used when in fallback mode
    *count_increment = 0;  // reset value back to zero
    // otherwise we have a conditional branch
    if (pbtb == NULL)
      {
        // BTB miss -- just return a predicted direction
        return ((*(dir_update_ptr->pdir1) >= 2)
	        ?  1  // taken
	        :  0); // not taken
      }
    else
      {
        // BTB hit, so return target if it's a predicted-taken branch
        return ((*(dir_update_ptr->pdir1) >= 2)
	        ?  pbtb->target  // taken
	        :  0);  // not taken
      }    
  }
  else {  // used when in replay mode
    st_index = head_pointer + *count_increment;  // calculate new index
    *count_increment = *count_increment + 1;  // increment value for next time function is called
    
    // otherwise we have a conditional branch
    if (pbtb == NULL) {
        // BTB miss -- just return a predicted direction
        if(!!(cb->buffer[st_index])) {  // base predictor was correct
          return ((*(dir_update_ptr->pdir1) >= 2)
	          ?  1  // taken
	          :  0);  // not taken
        }
        else {  // invert since base predictor was wrong
          pred->num_inverted_replay++;
          return ((*(dir_update_ptr->pdir1) >= 2)
	          ?  0  // not taken
	          :  1);  // taken
        
        }
    }
    else {  
        // BTB hit, so return target if it's a predicted-taken branch
        if(!!(cb->buffer[st_index])) {  // base predictor was correct
          return ((*(dir_update_ptr->pdir1) >= 2)
	        ?  pbtb->target  // taken
	        :  0);  // not taken
        }
        else { // invert since base predictor was wrong
          pred->num_inverted_replay++;
          return ((*(dir_update_ptr->pdir1) >= 2)
	        ?  0  // not taken
	        :  pbtb->target);  // taken
        }
    }   
  } 
}


/* Speculative execution can corrupt the ret-addr stack.  So for each
 * lookup we return the top-of-stack (TOS) at that point; a mispredicted
 * branch, as part of its recovery, restores the TOS using this value --
 * hopefully this uncorrupts the stack. */
void
bpred_recover(struct bpred_t *pred,	/* branch predictor instance */
	      md_addr_t baddr,		/* branch address */
	      int stack_recover_idx)	/* Non-speculative top-of-stack;
					 * used on mispredict recovery */
{
  if (pred == NULL)
    return;

  pred->retstack.tos = stack_recover_idx;
}

/* update the branch predictor, only useful for stateful predictors; updates
   entry for instruction type OP at address BADDR.  BTB only gets updated
   for branches which are taken.  Inst was determined to jump to
   address BTARGET and was taken if TAKEN is non-zero.  Predictor
   statistics are updated with result of prediction, indicated by CORRECT and
   PRED_TAKEN, predictor state to be updated is indicated by *DIR_UPDATE_PTR
   (may be NULL for jumps, which shouldn't modify state bits).  Note if
   bpred_update is done speculatively, branch-prediction may get polluted. */

// modified here
void
bpred_update(struct bpred_t *pred,	/* branch predictor instance */
	     md_addr_t baddr,		/* branch address */
	     md_addr_t btarget,		/* resolved branch target */
	     int taken,			/* non-zero if branch was taken */
	     int pred_taken,		/* non-zero if branch was pred taken */
	     int correct,		/* was earlier addr prediction ok? */
	     enum md_opcode op,		/* opcode of instruction */
	     struct bpred_update_t *dir_update_ptr, /* pred state pointer */
       CircBuffer_t* cb, /* receive the pointer to the circular buffer */
       CircTable_t* ct, /* receive the pointer to the circular head table  */
       bool *point_to_fallback_mode_ctr, /* return the control bit used to identify if we are in fallback mode or not */
       uint32_t *head_pointer) /* return the head pointer for the key that matched so it can be used in the other functions */
{
  struct bpred_btb_ent_t *pbtb = NULL;
  struct bpred_btb_ent_t *lruhead = NULL, *lruitem = NULL;
  int index, i;
// modified here
  bool we_are_in_fallback_mode = *point_to_fallback_mode_ctr; // receive the control bit used to identify if we are in fallback mode or replay
  struct key_var my_key; // hold the calculated value for the key
  struct key_match_head my_match; // hold the result for looking up for a key in the head table

  /* don't change bpred state for non-branch instructions or if this
   * is a stateless predictor*/
  if (!(MD_OP_FLAGS(op) & F_CTRL))
    return;

  /* Have a branch here */

  if (correct)
    pred->addr_hits++;

  if (!!pred_taken == !!taken)
    pred->dir_hits++;
  else
    pred->misses++;

  if (dir_update_ptr->dir.ras)
    {
      pred->used_ras++;
      if (correct)
	pred->ras_hits++;
    }
  else if ((MD_OP_FLAGS(op) & (F_CTRL|F_COND)) == (F_CTRL|F_COND))
    {
      if (dir_update_ptr->dir.meta)
	pred->used_2lev++;
      else
	pred->used_bimod++;
    }

  /* keep stats about JR's; also, but don't change any bpred state for JR's
   * which are returns unless there's no retstack */
  if (MD_IS_INDIR(op))
    {
      pred->jr_seen++;
      if (correct)
	pred->jr_hits++;

      if (!dir_update_ptr->dir.ras)
	{
	  pred->jr_non_ras_seen++;
	  if (correct)
	    pred->jr_non_ras_hits++;
	}
      else
	{
	  /* return that used the ret-addr stack; no further work to do */
	  return;
	}
    }

  /* Can exit now if this is a stateless predictor */
  if (pred->class == BPredNotTaken || pred->class == BPredTaken)
    return;

  /*
   * Now we know the branch didn't use the ret-addr stack, and that this
   * is a stateful predictor
   */

#ifdef RAS_BUG_COMPATIBLE
  /* if function call, push return-address onto return-address stack */
  if (MD_IS_CALL(op) && pred->retstack.size)
    {
      pred->retstack.tos = (pred->retstack.tos + 1)% pred->retstack.size;
      pred->retstack.stack[pred->retstack.tos].target =
	baddr + sizeof(md_inst_t);
      pred->retstack_pushes++;
    }
#endif /* RAS_BUG_COMPATIBLE */



  /* update L1 table if appropriate */
  /* L1 table is updated unconditionally for combining predictor too */
  if ((MD_OP_FLAGS(op) & (F_CTRL|F_UNCOND)) != (F_CTRL|F_UNCOND) &&
      (pred->class == BPred2Level || pred->class == BPredComb))
    {
      int l1index, shift_reg;

      /* also update appropriate L1 history register */
      l1index =
	(baddr >> MD_BR_SHIFT) & (pred->dirpred.twolev->config.two.l1size - 1);
      shift_reg =
	(pred->dirpred.twolev->config.two.shiftregs[l1index] << 1) | (!!taken);
      pred->dirpred.twolev->config.two.shiftregs[l1index] =
	shift_reg & ((1 << pred->dirpred.twolev->config.two.shift_width) - 1);
  

// modified here
	  // branch committed, so now update the circular buffer with prediction being correct or not
	  if((!!pred_taken) == (!!taken)) { // prediction and committed matched, so store bit value 1
        circ_buffer_push(cb, true);
	  }
    else circ_buffer_push(cb, false); // prediction and committed did not match, so store bit value 0
    pred->num_debug_test = cb->tail;

    // update the variables storing the past status to be used with hash function
    history_state_144.upper_16 = (history_state_144.upper_16 << 1) | (history_state_144.mid_64 >> 63);
    history_state_144.upper_16 = history_state_144.upper_16 & 0x0FFF;  // mask the upper 4 bits
    history_state_144.mid_64 = (history_state_144.mid_64 << 1) | (history_state_144.low_64 >> 63);
    history_state_144.low_64 = (history_state_144.low_64 << 1);
      
    if(!!taken) // decide to update last bit in the variable
      history_state_144.low_64++;
      
    if(we_are_in_fallback_mode == true) { // we are in fallback mode
      pred->num_operations_fallback++;
      if((!!pred_taken) != (!!taken)) { // base predictor made a mistake, so need to look if key is in the table
        my_key = hash_key(history_state_144, baddr); // compute the hash key
        my_match = circ_table_push(ct, cb, my_key);
        /*debug("Value history_state_144 = %lx %lx %lx \n", history_state_144.upper_16, history_state_144.mid_64, history_state_144.low_64);
        debug("Value my_key = %lx %lx %lx \n", my_key.data_up, my_key.data_mid, my_key.data_low);
        debug("Value my_match.match_bit = %x \n", my_match.match_bit);
        debug("Value my_match.match_head = %lx \n", my_match.match_head);   */

        if(my_match.match_bit) { // a match was found, so update variable to leave fallback mode
          we_are_in_fallback_mode = false;
          pred->num_entry_replay++;
          *head_pointer = my_match.match_head;
          /*debug("Circular buffer indice to start copying from replay mode = %d, indice where correction is performed is = %d \n", my_match.match_head, my_match.indice_new);
          count_increment = 0;
          debug("Value history_state_144 = %lx %lx %lx \n", history_state_144.upper_16, history_state_144.mid_64, history_state_144.low_64);
          debug("Value my_key = %lx %lx %lx \n", my_key.data_up, my_key.data_mid, my_key.data_low);
          debug("Value at *head_pointer = %lx \n", *head_pointer);  */
        }
      }
    }
    else { // we are in the replay mode
      pred->num_operations_replay++;
      if((!!pred_taken) != (!!taken)) { // adjusted predictor made a mistake, so need to stop the replay mode and enter fallback mode
        we_are_in_fallback_mode = true;
      }
    }
    
    *point_to_fallback_mode_ctr=we_are_in_fallback_mode; // make sure the mode control bit is pointed by the function argumnt
  }


  /* find BTB entry if it's a taken branch (don't allocate for non-taken) */
  if (taken)
    {
      index = (baddr >> MD_BR_SHIFT) & (pred->btb.sets - 1);

      if (pred->btb.assoc > 1)
	{
	  index *= pred->btb.assoc;

	  /* Now we know the set; look for a PC match; also identify
	   * MRU and LRU items */
	  for (i = index; i < (index+pred->btb.assoc) ; i++)
	    {
	      if (pred->btb.btb_data[i].addr == baddr)
		{
		  /* match */
		  assert(!pbtb);
		  pbtb = &pred->btb.btb_data[i];
		}

	      dassert(pred->btb.btb_data[i].prev
		      != pred->btb.btb_data[i].next);
	      if (pred->btb.btb_data[i].prev == NULL)
		{
		  /* this is the head of the lru list, ie current MRU item */
		  dassert(lruhead == NULL);
		  lruhead = &pred->btb.btb_data[i];
		}
	      if (pred->btb.btb_data[i].next == NULL)
		{
		  /* this is the tail of the lru list, ie the LRU item */
		  dassert(lruitem == NULL);
		  lruitem = &pred->btb.btb_data[i];
		}
	    }
	  dassert(lruhead && lruitem);

	  if (!pbtb)
	    /* missed in BTB; choose the LRU item in this set as the victim */
	    pbtb = lruitem;
	  /* else hit, and pbtb points to matching BTB entry */

	  /* Update LRU state: selected item, whether selected because it
	   * matched or because it was LRU and selected as a victim, becomes
	   * MRU */
	  if (pbtb != lruhead)
	    {
	      /* this splices out the matched entry... */
	      if (pbtb->prev)
		pbtb->prev->next = pbtb->next;
	      if (pbtb->next)
		pbtb->next->prev = pbtb->prev;
	      /* ...and this puts the matched entry at the head of the list */
	      pbtb->next = lruhead;
	      pbtb->prev = NULL;
	      lruhead->prev = pbtb;
	      dassert(pbtb->prev || pbtb->next);
	      dassert(pbtb->prev != pbtb->next);
	    }
	  /* else pbtb is already MRU item; do nothing */
	}
      else
	pbtb = &pred->btb.btb_data[index];
    }

  /*
   * Now 'p' is a possibly null pointer into the direction prediction table,
   * and 'pbtb' is a possibly null pointer into the BTB (either to a
   * matched-on entry or a victim which was LRU in its set)
   */

  /* update state (but not for jumps) */
  if (dir_update_ptr->pdir1)
    {
      if (taken)
	{
	  if (*dir_update_ptr->pdir1 < 3)
	    ++*dir_update_ptr->pdir1;
	}
      else
	{ /* not taken */
	  if (*dir_update_ptr->pdir1 > 0)
	    --*dir_update_ptr->pdir1;
	}
    }

  /* combining predictor also updates second predictor and meta predictor */
  /* second direction predictor */
  if (dir_update_ptr->pdir2)
    {
      if (taken)
	{
	  if (*dir_update_ptr->pdir2 < 3)
	    ++*dir_update_ptr->pdir2;
	}
      else
	{ /* not taken */
	  if (*dir_update_ptr->pdir2 > 0)
	    --*dir_update_ptr->pdir2;
	}
    }

  /* meta predictor */
  if (dir_update_ptr->pmeta)
    {
      if (dir_update_ptr->dir.bimod != dir_update_ptr->dir.twolev)
	{
	  /* we only update meta predictor if directions were different */
	  if (dir_update_ptr->dir.twolev == (unsigned int)taken)
	    {
	      /* 2-level predictor was correct */
	      if (*dir_update_ptr->pmeta < 3)
		++*dir_update_ptr->pmeta;
	    }
	  else
	    {
	      /* bimodal predictor was correct */
	      if (*dir_update_ptr->pmeta > 0)
		--*dir_update_ptr->pmeta;
	    }
	}
    }

  /* update BTB (but only for taken branches) */
  if (pbtb)
    {
      /* update current information */
      dassert(taken);

      if (pbtb->addr == baddr)
	{
	  if (!correct)
	    pbtb->target = btarget;
	}
      else
	{
	  /* enter a new branch in the table */
	  pbtb->addr = baddr;
	  pbtb->op = op;
	  pbtb->target = btarget;
	}
    }
}


///////////////////// Functions used to write info to files at the end of debug /////////////////////////////

int write_file_CB(char *name_file, CircBuffer_t* cb){ // used for the circular buffer when writing to file
  int j;
  
  FILE *file_p = fopen(name_file, "w");  // create file in write mode and get pointer

  if(file_p == NULL) {  // verify if file was created
    debug("Error creating circular buffer file!\n");
    return 0;
  }

  if((cb->tail) >= (cb->head)) { // write to file when buffer is not wrapped around
    for(j=(cb->head);j<=(cb->tail);j++) {
      fprintf(file_p,"index= %d, value= 0x%x\n",j,cb->buffer[j]);
    }
  }
  else {  // file wrapped around, so use this format to print
    for(j=cb->head;j<cb->max_qty;j++) {
      fprintf(file_p,"index= %d, value= 0x%x\n",j,cb->buffer[j]);
    }
    for(j=0;j<=cb->tail;j++) {
      fprintf(file_p,"index= %d, value= 0x%x\n",j,cb->buffer[j]);
    }    
  }

  fclose(file_p); // Close the file after done writing

  return 1;
}



int write_file_CT(const char *name_file, CircTable_t *ct){ // used for the circular head table when writing to file
  int j;
  FILE *file_p = fopen(name_file, "w");  // create file in write mode and get pointer

  if(file_p == NULL) {  // verify if file was created
    debug("Error creating circular head table file!\n");
    return 0;
    }
  
   if((ct->tail) >= (ct->head)) { // write to file when buffer is not wrapped around
     for(j=ct->head;j<=ct->tail;j++) {
       fprintf(file_p,"index= %d, key= 0x%llx %llx %llx, head pointer= 0x%lx\n",j,(long long unsigned int)ct->buffer[j].key_line.data_up,(long long unsigned int)ct->buffer[j].key_line.data_mid,(long long unsigned int)ct->buffer[j].key_line.data_low,(long unsigned int)ct->buffer[j].head_start);
     }
   }
   else {  // file wrapped around, so use this format to print
     for(j=ct->head;j<ct->max_qty;j++) {
       fprintf(file_p,"index= %d, key= 0x%llx %llx %llx, head pointer= 0x%lx\n",j,(long long unsigned int)ct->buffer[j].key_line.data_up,(long long unsigned int)ct->buffer[j].key_line.data_mid,(long long unsigned int)ct->buffer[j].key_line.data_low,(long unsigned int)ct->buffer[j].head_start);
     }
     for(j=0;j<=ct->tail;j++) {
       fprintf(file_p,"index= %d, key= 0x%llx %llx %llx, head pointer= 0x%lx\n",j,(long long unsigned int)ct->buffer[j].key_line.data_up,(long long unsigned int)ct->buffer[j].key_line.data_mid,(long long unsigned int)ct->buffer[j].key_line.data_low,(long unsigned int)ct->buffer[j].head_start);
     }    
   }

  fclose(file_p); // Close the file after done writing

  return 1;
}

